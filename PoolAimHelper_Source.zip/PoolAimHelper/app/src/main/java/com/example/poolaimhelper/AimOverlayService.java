package com.example.poolaimhelper;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

public class AimOverlayService extends Service {
    private WindowManager wm;
    private FrameLayout panel;
    private WindowManager.LayoutParams params;
    @Override public void onCreate() {
        super.onCreate(); wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        panel = new FrameLayout(this);
        AimView aim = new AimView();
        panel.addView(aim, new FrameLayout.LayoutParams(280, 280));
        TextView close = new TextView(this); close.setText(" × "); close.setTextSize(22); close.setTextColor(Color.WHITE); close.setBackgroundColor(0xCC222222); close.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(70, 54, Gravity.TOP | Gravity.RIGHT);
        panel.addView(close, cp); close.setOnClickListener(v -> stopSelf());
        params = new WindowManager.LayoutParams(280, 280, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                android.graphics.PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT; params.x = 40; params.y = 220;
        wm.addView(panel, params);
        panel.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { sx=e.getRawX(); sy=e.getRawY(); ox=params.x; oy=params.y; return true; }
                if (e.getAction() == MotionEvent.ACTION_MOVE) { params.x=ox+(int)(e.getRawX()-sx); params.y=oy+(int)(e.getRawY()-sy); wm.updateViewLayout(panel,params); return true; }
                return false;
            }
        });
        // Let the aiming view handle its own angle/line gestures; panel drag is used only outside its drawing area.
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_NOT_STICKY; }
    @Override public void onDestroy() { if (panel != null && panel.isAttachedToWindow()) wm.removeView(panel); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }

    private class AimView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float angle = -0.65f, cx = 120, cy = 155; float downAngle, downX, downY; boolean rotating=false;
        AimView() { super(AimAimContext()); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        private android.content.Context AimAimContext() { return AimAimServiceContext(); }
        private android.content.Context AimAimServiceContext() { return AimAimService.this; }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            p.setColor(0x99071120); p.setStyle(Paint.Style.FILL); c.drawRoundRect(new RectF(8,8,getWidth()-8,getHeight()-8),18,18,p);
            p.setColor(Color.WHITE); p.setTextSize(15); c.drawText("اسحب المقبض لتغيير الزاوية",18,28,p);
            float len=100; float ex=cx+(float)Math.cos(angle)*len, ey=cy+(float)Math.sin(angle)*len;
            p.setColor(0xFFFFD54F); p.setStrokeWidth(5); p.setStyle(Paint.Style.STROKE); c.drawLine(cx,cy,ex,ey,p);
            p.setStyle(Paint.Style.FILL); c.drawCircle(cx,cy,10,p); c.drawCircle(ex,ey,13,p);
            p.setColor(Color.BLACK); c.drawCircle(ex,ey,5,p);
            p.setColor(Color.WHITE); p.setTextSize(14); c.drawText(String.format(java.util.Locale.US,"زاوية: %.0f°",Math.toDegrees(angle)),18,getHeight()-18,p);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX(), y=e.getY();
            switch(e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX=x; downY=y; rotating=Math.hypot(x-(cx+Math.cos(angle)*100), y-(cy+Math.sin(angle)*100))<40; downAngle=angle; return true;
                case MotionEvent.ACTION_MOVE:
                    if (rotating) angle=(float)Math.atan2(y-cy,x-cx);
                    else { cx=Math.max(25,Math.min(getWidth()-25,cx+x-downX)); cy=Math.max(45,Math.min(getHeight()-25,cy+y-downY)); downX=x; downY=y; }
                    invalidate(); return true;
                case MotionEvent.ACTION_UP: rotating=false; return true;
            }
            return true;
        }
    }
}
