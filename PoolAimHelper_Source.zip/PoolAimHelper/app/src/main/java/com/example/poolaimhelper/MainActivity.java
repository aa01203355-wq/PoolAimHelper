package com.example.poolaimhelper;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 101;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 48, 36, 36);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title = new TextView(this);
        title.setText("Pool Aim Helper"); title.setTextSize(26); title.setGravity(Gravity.CENTER);
        TextView desc = new TextView(this);
        desc.setText("مساعد تصويب عائم يدوي للعبة 8 Ball Pool. حرّك خط التصويب بنفسك؛ التطبيق لا يقرأ اللعبة ولا يضمن دخول الكرات.\n\n1) فعّل إذن الظهور فوق التطبيقات.\n2) ارجع واضغط تشغيل الأداة.\n3) اسحب الخط لتغيير مكانه، واسحب المقبض الدائري لتغيير زاويته.");
        desc.setTextSize(17); desc.setPadding(0, 24, 0, 24);
        Button enable = new Button(this); enable.setText("تفعيل إذن الظهور فوق التطبيقات");
        enable.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, REQUEST_OVERLAY);
            } else startOverlay();
        });
        Button start = new Button(this); start.setText("تشغيل أداة التصويب العائمة");
        start.setOnClickListener(v -> { if (Settings.canDrawOverlays(this)) startOverlay(); else enable.performClick(); });
        Button stop = new Button(this); stop.setText("إيقاف الأداة");
        stop.setOnClickListener(v -> stopService(new Intent(this, AimOverlayService.class)));
        layout.addView(title); layout.addView(desc); layout.addView(enable); layout.addView(start); layout.addView(stop);
        setContentView(layout);
    }
    private void startOverlay() { startService(new Intent(this, AimOverlayService.class)); }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY && Settings.canDrawOverlays(this)) startOverlay();
    }
}
